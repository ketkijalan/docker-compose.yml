# BusyWork: Everyday access for all

A voice-first prototype that helps elderly people living alone book a cab, order
groceries and order medicines by speaking, in Hindi, English or a mix of both.

## Run it (one command)

    docker compose up --build

Open http://localhost:8080 in **Google Chrome** (best speech support) and allow the microphone.
No API keys are needed. The "Remain with me" chat shows "key not set" and uses
simple built-in replies instead.

You can also open `app/index.html` directly in Chrome.

## How it works
1. BusyWork greets: "Hi! What should I look for you today?"
2. It understands the request (`intents.js`) and repeats it back.
3. It reads the details slowly, then asks for an explicit yes before "paying".
4. "Stay here please" mode repeats reminders if the user goes quiet.
5. After two misunderstandings, or three reminders, it shows the helpline.
6. "Remain with me" is a 10-minute friendly chat mode.

## Demo limits (honest scope)
- Bookings and payments are **simulated**. Nothing is really booked or charged.
- Face authentication, lip reading and password-manager steps are on the roadmap, not in this prototype.
- Music playback is not set up in this demo.
- Helpline number 14567 is India's Elderline; verify before real use.

## Files
- `app/index.html`, `app/style.css`: large-button interface
- `app/voice.js`: speaking and listening (browser Web Speech API)
- `app/strings.js`: all Hindi and English sentences
- `app/intents.js`: understands cab / groceries / medicines / yes / no
- `app/flow.js`: conversation steps, reminders, helpline, "Remain with me"

## AI disclosure
This project was built with the help of Claude (an AI assistant made by Anthropic).
