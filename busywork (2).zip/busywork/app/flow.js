// The conversation: greet, listen, understand, confirm twice, "pay" (simulated).
// Also: "Stay here please" reminders, helpline fallback, and "Remain with me".
(function () {
  const $ = id => document.getElementById(id);

  const S = {
    lang: "en-IN",
    step: "ask",        // ask | confirm | pay | chat
    pending: null,      // the booking waiting for confirmation
    fails: 0,           // misunderstandings in a row
    reminders: 0,       // "stay here" reminders in a row
    idleTimer: null,
    listening: false,
    chatEnd: 0,
    chatTurns: 0,
    started: false,
    awaitDest: false    // true after "Where do you want to go?"
  };

  const t = () => STR[S.lang];

  // ---------- small helpers ----------
  function show(text) { $("message").textContent = text; }
  function showHeard(text) { $("heard").textContent = text ? "I heard: " + text : ""; }

  async function say(text) {
    show(text);
    await Voice.speak(text, S.lang);
  }

  function setListening(on) {
    S.listening = on;
    $("mic").classList.toggle("listening", on);
    $("mic-label").textContent = on ? "..." : t().speak;
  }

  function refreshButtons() {
    $("yesno").hidden = !(S.step === "confirm" || S.step === "pay");
  }

  function setLang(lang) {
    S.lang = lang;
    document.documentElement.lang = lang === "hi-IN" ? "hi" : "en";
    $("lang-en").classList.toggle("on", lang === "en-IN");
    $("lang-hi").classList.toggle("on", lang === "hi-IN");
    $("lang-en").setAttribute("aria-pressed", String(lang === "en-IN"));
    $("lang-hi").setAttribute("aria-pressed", String(lang === "hi-IN"));
    $("mic-label").textContent = t().speak;
    $("helpline-text").textContent = t().helplineBox;
  }

  function showHelpline() { $("helpline").hidden = false; }

  // ---------- "Stay here please" mode ----------
  function clearIdle() {
    if (S.idleTimer) { clearTimeout(S.idleTimer); S.idleTimer = null; }
  }

  // While a task is half-finished, remind the user every 20 seconds.
  function armIdle() {
    clearIdle();
    if (S.step === "ask" || S.step === "chat") return;
    S.idleTimer = setTimeout(async () => {
      S.reminders++;
      if (S.reminders >= 3) {
        showHelpline();
        await say(t().helplineMsg);
        S.reminders = 0;
        return;
      }
      await say(t().stayHere);
      armIdle();
    }, 20000);
  }

  // ---------- understanding failures ----------
  async function fail() {
    S.fails++;
    if (S.fails >= 2) {
      showHelpline();
      S.fails = 0;
      await say(t().helplineMsg);
    } else {
      await say(t().tryAgain);
    }
    armIdle();
  }

  // ---------- price (simulated) ----------
  function priceFor(b) {
    if (b.type === "cab") return 180;
    if (b.type === "grocery") return 40 + 60 * Math.max(1, b.items.length);
    return 250;
  }

  function groceryList(items) {
    if (!items.length) return t().anyGrocery;
    return items.map(k => GROCERY_ITEMS[k][S.lang]).join(", ");
  }

  // ---------- Step 2: understand and repeat back ----------
  async function propose(intent) {
    S.fails = 0;
    S.reminders = 0;

    if (intent.type === "chat") { startChat(); return; }

    if (intent.type === "cab" && !intent.destination) {
      S.awaitDest = true;
      await say(t().askCab);
      return; // the next thing said is treated as the destination
    }

    const b = { type: intent.type };
    if (b.type === "cab") b.destination = intent.destination;
    if (b.type === "grocery") b.items = intent.items;
    if (b.type === "medicine") b.medicine = intent.medicine || t().anyMedicine;
    b.price = priceFor(b);
    S.pending = b;
    S.step = "confirm";
    refreshButtons();

    let sentence;
    if (b.type === "cab") sentence = t().cab(b.destination);
    else if (b.type === "grocery") sentence = t().grocery(groceryList(b.items));
    else sentence = t().medicine(b.medicine);
    await say(sentence);
    armIdle();
  }

  // ---------- Steps 3 and 4: read the details, then ask before paying ----------
  async function readDetailsAndAskToPay() {
    const b = S.pending;
    let details;
    if (b.type === "cab") details = t().cabDetails(b.destination, b.price);
    else if (b.type === "grocery") details = t().groceryDetails(groceryList(b.items), b.price);
    else details = t().medicineDetails(b.medicine, b.price);

    S.step = "pay";
    refreshButtons();
    await say(details);
    await say(t().payAsk(b.price));
    armIdle();
  }

  function saveBooking(b) {
    // Simulated only. Kept in this browser to show a history later.
    try {
      const list = JSON.parse(localStorage.getItem("busywork-bookings") || "[]");
      list.push({ ...b, at: new Date().toISOString() });
      localStorage.setItem("busywork-bookings", JSON.stringify(list.slice(-20)));
    } catch (e) { /* storage may be blocked; ignore */ }
  }

  async function finishOrCancel(yes) {
    clearIdle();
    S.reminders = 0;
    if (yes) {
      saveBooking(S.pending);
      S.pending = null;
      S.step = "ask";
      refreshButtons();
      await say(t().done);
      await say(t().again);
    } else {
      S.pending = null;
      S.step = "ask";
      refreshButtons();
      await say(t().cancelled);
    }
  }

  async function onYesNo(answer) {
    if (answer === null) { await say(t().unclearYesNo); armIdle(); return; }
    if (answer === "no") { await finishOrCancel(false); return; }
    if (S.step === "confirm") { await readDetailsAndAskToPay(); return; }
    await finishOrCancel(true); // second explicit yes before "payment"
  }

  // ---------- one thing the user said or typed ----------
  async function handle(text) {
    clearIdle();
    showHeard(text);
    if (Intents.hasDevanagari(text) && S.lang !== "hi-IN") setLang("hi-IN");

    if (S.step === "chat") { await chatReply(text); return; }
    if (S.step === "confirm" || S.step === "pay") { await onYesNo(Intents.yesNo(text)); return; }

    // The cab destination arrives alone after "Where do you want to go?"
    if (S.awaitDest) {
      S.awaitDest = false;
      await propose({ type: "cab", destination: text.trim() });
      return;
    }
    const intent = Intents.detect(text);
    if (!intent) { await fail(); return; }
    await propose(intent);
  }

  // ---------- listening ----------
  async function listenOnce() {
    if (!Voice.canListen) { showHelpline(); await say(t().noMic); return; }
    if (S.listening) { Voice.stop(); setListening(false); return; }
    clearIdle();
    Voice.stop();
    setListening(true);
    show(t().listening);
    try {
      const text = await Voice.listen(S.lang);
      setListening(false);
      await handle(text);
    } catch (err) {
      setListening(false);
      if (err && err.message === "not-allowed") { await say(t().noMic); return; }
      await fail();
    }
  }

  // ---------- "Remain with me": a 10-minute friendly chat ----------
  async function startChat() {
    S.step = "chat";
    S.chatTurns = 0;
    S.chatEnd = Date.now() + 10 * 60 * 1000;
    refreshButtons();
    $("banner").textContent = t().chatNoKey; // AI_KEY is empty, so simple replies are used
    await say(t().chatOpen);
    if (Voice.canListen) chatLoop();
  }

  function endChat(message) {
    S.step = "ask";
    refreshButtons();
    return say(message).then(() => say(t().again));
  }

  async function chatReply(text) {
    if (Intents.wantsToStop(text)) { await endChat(t().chatEnd); return; }
    if (Date.now() > S.chatEnd) { await endChat(t().chatEndTimeUp); return; }

    const lower = text.toLowerCase();
    let reply;
    if (Intents.anyOf(lower, ["sad", "lonely", "low", "alone", "tired", "udaas", "उदास", "अकेला", "अकेली", "थका"])) reply = t().chatSad;
    else if (Intents.anyOf(lower, ["music", "song", "gaana", "gana", "संगीत", "गाना"])) reply = t().chatMusic;
    else if (Intents.anyOf(lower, ["good", "happy", "fine", "great", "accha", "achha", "अच्छा", "खुश"])) reply = t().chatHappy;
    else reply = t().chatMore[S.chatTurns % t().chatMore.length];
    S.chatTurns++;
    await say(reply);
  }

  async function chatLoop() {
    while (S.step === "chat") {
      try {
        setListening(true);
        const text = await Voice.listen(S.lang);
        setListening(false);
        if (S.step !== "chat") return;
        showHeard(text);
        if (Intents.hasDevanagari(text) && S.lang !== "hi-IN") setLang("hi-IN");
        await chatReply(text);
      } catch (err) {
        setListening(false);
        if (err && err.message === "not-allowed") { await endChat(t().noMic); return; }
        if (Date.now() > S.chatEnd) { await endChat(t().chatEndTimeUp); return; }
        // Silence is fine in a chat: wait a moment and keep listening.
        await new Promise(r => setTimeout(r, 800));
      }
    }
  }

  // ---------- wire up the page ----------
  function start() {
    if (S.started) return;
    S.started = true;
    say(t().greet);
  }

  $("mic").addEventListener("click", () => {
    // Browsers only allow audio after a tap, so the greeting plays on the first tap.
    if (!S.started) { S.started = true; say(t().greet).then(listenOnce); return; }
    listenOnce();
  });

  $("yes").addEventListener("click", () => { Voice.stop(); clearIdle(); onYesNo("yes"); });
  $("no").addEventListener("click", () => { Voice.stop(); clearIdle(); onYesNo("no"); });

  document.querySelectorAll("[data-intent]").forEach(btn => {
    btn.addEventListener("click", () => {
      Voice.stop();
      S.started = true;
      const type = btn.dataset.intent;
      if (type === "cab") { S.step = "ask"; S.awaitDest = true; say(t().askCab); return; }
      propose(type === "grocery" ? { type, items: [] } : { type, medicine: null });
    });
  });

  $("remain").addEventListener("click", () => { Voice.stop(); S.started = true; startChat(); });
  $("lang-en").addEventListener("click", () => setLang("en-IN"));
  $("lang-hi").addEventListener("click", () => setLang("hi-IN"));

  function sendTyped() {
    const box = $("typed-input");
    const text = box.value.trim();
    if (!text) return;
    box.value = "";
    S.started = true;
    handle(text);
  }
  $("typed-send").addEventListener("click", sendTyped);
  $("typed-input").addEventListener("keydown", e => { if (e.key === "Enter") sendTyped(); });

  setLang("en-IN");
  show(t().tapToSpeak);
  if (!Voice.canListen) {
    $("banner").textContent = "Voice listening needs Google Chrome. You can still use the buttons or type.";
    showHelpline();
  }
})();
