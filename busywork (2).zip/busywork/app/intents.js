// Understands what the user wants from a sentence in English, Hindi, or a mix.
const Intents = (function () {
  const DEVANAGARI = /[\u0900-\u097F]/;

  const RULES = [
    { type: "chat", words: ["lonely", "alone", "remain", "akela", "akeli", "अकेला", "अकेली", "बात करो", "बातें"] },
    { type: "cab", words: ["cab", "taxi", "ride", "uber", "ola", "auto", "gaadi", "कैब", "टैक्सी", "गाड़ी", "गाडी", "ऑटो"] },
    { type: "medicine", words: ["medicine", "medicines", "medical", "pharmacy", "tablet", "dawa", "dawai", "दवा", "दवाई", "दवाइयाँ", "दवाइयां", "गोली"] },
    { type: "grocery", words: ["grocery", "groceries", "kirana", "ration", "राशन", "किराना", "सामान"] }
  ];
  const YES = ["yes", "yeah", "yep", "ok", "okay", "sure", "correct", "right", "confirm", "pay", "haan", "han", "ha", "ji", "theek", "thik", "sahi", "हाँ", "हां", "हा", "जी", "ठीक", "सही"];
  const NO = ["no", "nope", "cancel", "stop", "wait", "nahi", "nahin", "na", "ruko", "नहीं", "नही", "ना", "रुको", "रुकिए", "मत"];
  const FILLER = /\b(please|book|a|an|the|me|my|i|want|need|cab|taxi|ride|kar|karo|do|bhai|one)\b|बुक|करो|कीजिए|कर दो|कैब|टैक्सी|मुझे|एक|चाहिए/gi;

  // Latin words must match whole words; Devanagari words can match anywhere.
  function has(text, tokens, word) {
    return DEVANAGARI.test(word) ? text.includes(word) : tokens.includes(word);
  }
  function anyOf(text, list) {
    const tokens = text.split(/[^a-z]+/);
    return list.some(w => has(text, tokens, w));
  }

  function hasDevanagari(text) { return DEVANAGARI.test(text); }

  // Pick out the place from "cab to Colaba house 7" / "कोलाबा जाना है" / "Colaba jana hai".
  function findDestination(raw) {
    const patterns = [
      /(?:\bto\b|\bfor\b|\bat\b|\btowards\b)\s+(.+)$/i,
      /(.+?)\s*(?:जाना|जाऊँगा|जाऊंगा|तक|के लिए|को)(?=\s|$)/,
      /(.+?)\s+(?:jana|jaana|tak|ke liye)\b/i
    ];
    for (const p of patterns) {
      const m = raw.match(p);
      if (m && m[1]) {
        const cleaned = m[1].replace(FILLER, " ").replace(/\s+/g, " ").replace(/^[,\s]+|[,\s]+$/g, "");
        if (cleaned.length > 1) return cleaned;
      }
    }
    return null;
  }

  function findGroceries(text) {
    const tokens = text.split(/[^a-z]+/);
    return Object.keys(GROCERY_ITEMS).filter(k =>
      GROCERY_ITEMS[k].words.some(w => has(text, tokens, w)));
  }

  function findMedicine(raw) {
    const m = raw.match(/(?:\bfor\b|\bof\b)\s+(.+)$/i) || raw.match(/(.+?)\s*(?:की दवा|की दवाई|ki dawa|ki dawai)/i);
    return m && m[1] ? m[1].trim() : null;
  }

  // Returns { type, destination | items | medicine } or null if not understood.
  function detect(raw) {
    const text = raw.toLowerCase();
    for (const rule of RULES) {
      if (!anyOf(text, rule.words)) continue;
      if (rule.type === "cab") return { type: "cab", destination: findDestination(raw) };
      if (rule.type === "grocery") return { type: "grocery", items: findGroceries(text) };
      if (rule.type === "medicine") return { type: "medicine", medicine: findMedicine(raw) };
      return { type: "chat" };
    }
    const items = findGroceries(text);
    if (items.length) return { type: "grocery", items };
    return null;
  }

  // Returns "yes", "no" or null. "No" is checked first so "no, wait" never counts as yes.
  function yesNo(raw) {
    const text = raw.toLowerCase();
    if (anyOf(text, NO)) return "no";
    if (anyOf(text, YES)) return "yes";
    return null;
  }

  function wantsToStop(raw) {
    return anyOf(raw.toLowerCase(), ["bye", "stop", "quit", "enough", "bas", "बस", "रुको", "अलविदा"]);
  }

  return { detect, yesNo, wantsToStop, hasDevanagari, anyOf };
})();
