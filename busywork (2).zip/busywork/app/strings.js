// All spoken and shown sentences, in English (en-IN) and Hindi (hi-IN).
// Short sentences on purpose: easier to follow for elderly users.
const HELPLINE_NUMBER = "14567"; // India Elderline; verify before real use
const AI_KEY = "";               // No secret keys in this repo. Empty means "key not set".

const STR = {
  "en-IN": {
    greet: "Hi! What should I look for you today?",
    tapToSpeak: "Tap the big button and speak.",
    listening: "I am listening.",
    speak: "Speak",
    tryAgain: "Sorry, I did not catch that. Please say it again, slowly.",
    helplineMsg: "Let me connect you to the helpline. The number is " + HELPLINE_NUMBER + ".",
    helplineBox: "Need help? Call the helpline: " + HELPLINE_NUMBER,
    noMic: "Voice is not working here. Please use the buttons, or type your request.",
    stayHere: "Please stay here. I am waiting for your answer.",
    askCab: "Where do you want to go?",
    cab: d => "You want a cab to " + d + ". Is that right?",
    grocery: l => "You want to order " + l + ". Is that right?",
    medicine: m => "You want to order " + m + ". Is that right?",
    anyMedicine: "your regular medicines",
    anyGrocery: "your groceries",
    cabDetails: (d, p) => "Your cab will go to " + d + ". The fare is about " + p + " rupees.",
    groceryDetails: (l, p) => "Your order is " + l + ". The total is about " + p + " rupees.",
    medicineDetails: (m, p) => "Your order is " + m + ". The total is about " + p + " rupees.",
    payAsk: p => "Shall I pay " + p + " rupees? Say yes to pay, or no to cancel.",
    unclearYesNo: "Please say yes or no.",
    done: "Done! Your booking is complete. Nothing was really charged, this is a demo.",
    cancelled: "Okay, I have cancelled. What else can I do for you?",
    again: "What else should I look for you?",
    chatNoKey: "Chat AI key not set. Using simple replies.",
    chatOpen: "I am here with you for ten minutes. How are you feeling today?",
    chatSad: "I am sorry you feel low. I am right here. Would you like to tell me about your day?",
    chatMusic: "I would love to play music for you. Music is not set up in this demo yet.",
    chatHappy: "That is lovely to hear. Tell me more.",
    chatMore: ["Tell me more.", "I am listening.", "That sounds interesting. What happened next?", "I am glad to talk with you."],
    chatEnd: "It was nice talking with you. I am always here when you need me.",
    chatEndTimeUp: "Our ten minutes are over. Thank you for the lovely chat."
  },
  "hi-IN": {
    greet: "नमस्ते! आज मैं आपके लिए क्या ढूँढूँ?",
    tapToSpeak: "बड़ा बटन दबाइए और बोलिए।",
    listening: "मैं सुन रहा हूँ।",
    speak: "बोलिए",
    tryAgain: "माफ़ कीजिए, मैं समझ नहीं पाया। कृपया धीरे से फिर बोलिए।",
    helplineMsg: "मैं आपको हेल्पलाइन से जोड़ता हूँ। नंबर है " + HELPLINE_NUMBER + "।",
    helplineBox: "मदद चाहिए? हेल्पलाइन पर फ़ोन कीजिए: " + HELPLINE_NUMBER,
    noMic: "यहाँ आवाज़ काम नहीं कर रही। कृपया बटन दबाइए या लिखकर बताइए।",
    stayHere: "कृपया यहीं रहिए। मैं आपके जवाब का इंतज़ार कर रहा हूँ।",
    askCab: "आपको कहाँ जाना है?",
    cab: d => "आपको " + d + " के लिए कैब चाहिए। क्या यह सही है?",
    grocery: l => "आप " + l + " मँगवाना चाहते हैं। क्या यह सही है?",
    medicine: m => "आप " + m + " मँगवाना चाहते हैं। क्या यह सही है?",
    anyMedicine: "अपनी नियमित दवाइयाँ",
    anyGrocery: "अपना राशन",
    cabDetails: (d, p) => "आपकी कैब " + d + " जाएगी। किराया लगभग " + p + " रुपये है।",
    groceryDetails: (l, p) => "आपका ऑर्डर है " + l + "। कुल लगभग " + p + " रुपये।",
    medicineDetails: (m, p) => "आपका ऑर्डर है " + m + "। कुल लगभग " + p + " रुपये।",
    payAsk: p => "क्या मैं " + p + " रुपये का भुगतान करूँ? भुगतान के लिए हाँ बोलिए, रद्द करने के लिए नहीं।",
    unclearYesNo: "कृपया हाँ या नहीं बोलिए।",
    done: "हो गया! आपकी बुकिंग पूरी हुई। असल में कोई पैसा नहीं कटा, यह डेमो है।",
    cancelled: "ठीक है, मैंने रद्द कर दिया। और क्या कर सकता हूँ?",
    again: "और क्या ढूँढूँ आपके लिए?",
    chatNoKey: "चैट AI की कुंजी सेट नहीं है। साधारण जवाब इस्तेमाल हो रहे हैं।",
    chatOpen: "मैं दस मिनट आपके साथ हूँ। आज आप कैसा महसूस कर रहे हैं?",
    chatSad: "मुझे दुख है कि आप उदास हैं। मैं यहीं हूँ। क्या आप अपने दिन के बारे में बताएँगे?",
    chatMusic: "मुझे आपके लिए संगीत बजाना अच्छा लगेगा। इस डेमो में संगीत अभी सेट नहीं है।",
    chatHappy: "यह सुनकर बहुत अच्छा लगा। और बताइए।",
    chatMore: ["और बताइए।", "मैं सुन रहा हूँ।", "यह दिलचस्प है। फिर क्या हुआ?", "आपसे बात करके अच्छा लग रहा है।"],
    chatEnd: "आपसे बात करके अच्छा लगा। जब ज़रूरत हो, मैं यहीं हूँ।",
    chatEndTimeUp: "हमारे दस मिनट पूरे हुए। इतनी अच्छी बातचीत के लिए धन्यवाद।"
  }
};

// Grocery words BusyWork knows, with a name to read out in each language.
const GROCERY_ITEMS = {
  milk:   { words: ["milk", "doodh", "दूध"],               "en-IN": "milk",       "hi-IN": "दूध" },
  rice:   { words: ["rice", "chawal", "चावल"],             "en-IN": "rice",       "hi-IN": "चावल" },
  atta:   { words: ["atta", "flour", "आटा"],               "en-IN": "atta",       "hi-IN": "आटा" },
  dal:    { words: ["dal", "lentils", "दाल"],              "en-IN": "dal",        "hi-IN": "दाल" },
  sugar:  { words: ["sugar", "chini", "चीनी"],             "en-IN": "sugar",      "hi-IN": "चीनी" },
  tea:    { words: ["tea", "chai", "चाय"],                 "en-IN": "tea",        "hi-IN": "चाय" },
  bread:  { words: ["bread", "ब्रेड"],                      "en-IN": "bread",      "hi-IN": "ब्रेड" },
  eggs:   { words: ["egg", "eggs", "anda", "अंडा", "अंडे"], "en-IN": "eggs",       "hi-IN": "अंडे" },
  veg:    { words: ["vegetables", "sabzi", "सब्ज़ी", "सब्जी"], "en-IN": "vegetables", "hi-IN": "सब्ज़ी" }
};
