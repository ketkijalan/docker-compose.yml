// Speaking and listening using the browser's built-in Web Speech API.
// No keys needed. Works best in Google Chrome.
const Voice = (function () {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const canListen = !!SR;
  const canSpeak = "speechSynthesis" in window;
  let current = null;

  // Speak slowly (rate 0.85). Resolves when the sentence has finished.
  function speak(text, lang) {
    return new Promise(resolve => {
      if (!canSpeak) { resolve(); return; }
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang;
      u.rate = 0.85;
      u.onend = () => resolve();
      u.onerror = () => resolve();
      window.speechSynthesis.speak(u);
    });
  }

  // Listen once. Resolves with the text, or rejects with a reason.
  function listen(lang) {
    return new Promise((resolve, reject) => {
      if (!canListen) { reject(new Error("unsupported")); return; }
      stop();
      const rec = new SR();
      current = rec;
      rec.lang = lang;
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      let got = false;
      rec.onresult = e => {
        got = true;
        resolve(e.results[0][0].transcript.trim());
      };
      rec.onerror = e => { if (!got) { got = true; reject(new Error(e.error || "error")); } };
      rec.onend = () => { if (!got) { got = true; reject(new Error("no-speech")); } };
      try { rec.start(); } catch (err) { reject(err); }
    });
  }

  function stop() {
    if (current) { try { current.abort(); } catch (e) { /* ignore */ } current = null; }
    if (canSpeak) window.speechSynthesis.cancel();
  }

  return { speak, listen, stop, canListen, canSpeak };
})();
